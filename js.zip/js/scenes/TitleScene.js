/**
 * TitleScene — 起始标题页面
 * Hollow Knight 风格：暗黑背景 + 大标题 + 居中菜单按钮
 * 按钮：START / TUTORIAL / QUIT
 */
class TitleScene extends Phaser.Scene {
    constructor() { super('TitleScene'); }

    preload() {
        if (typeof AudioSystem !== 'undefined') AudioSystem.loadAll(this);  // 加载全部音频
        // 标题页背景图（洞穴）
        this.load.image('Tittle_scene_background_image', 'assets/images/Tittle_scene_background_image.png');
    }

    create() {
        // 复位状态 — 场景重启 (Save&Exit 回主页) 时实例属性会残留, 不清会卡死所有按钮
        this._fading = false;
        this._modalOpen = false;
        if (this.cameras && this.cameras.main) this.cameras.main.resetFX();
        if (typeof AudioSystem !== 'undefined') AudioSystem.bgm(this, 'bgm_TitleScene');  // BGM
        // 等 VT323 字体加载好再渲染（避免 fallback 字体显示尺寸不一致）
        if (document.fonts && document.fonts.load) {
            // 触发加载
            document.fonts.load('30px "VT323"').then(() => this._doCreate());
            document.fonts.load('40px "VT323"');
            document.fonts.load('72px "VT323"');
            return;
        }
        this._doCreate();
    }

    _doCreate() {
        const W = this.cameras.main.width;
        const H = this.cameras.main.height;

        // 背景：用洞穴图片（如果加载成功），失败则回退到渐变
        if (this.textures.exists('Tittle_scene_background_image')) {
            let img = this.add.image(W / 2, H / 2, 'Tittle_scene_background_image');
            // 缩放铺满画面（保持比例 → 用 max 让短边铺满）
            let scale = Math.max(W / img.width, H / img.height);
            img.setScale(scale);
            // 上面盖一层半透明黑色（让标题文字更清晰）
            this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.35);
        } else {
            // fallback：原本的渐变背景
            let bg = this.add.graphics();
            bg.fillGradientStyle(0x0a0a1a, 0x0a0a1a, 0x000000, 0x000000, 1);
            bg.fillRect(0, 0, W, H);
        }

        // 装饰：随机闪烁的小水晶点
        for (let i = 0; i < 60; i++) {
            let star = this.add.circle(
                Phaser.Math.Between(0, W),
                Phaser.Math.Between(0, H),
                Phaser.Math.Between(1, 2),
                0x88aaff, Phaser.Math.FloatBetween(0.3, 0.9)
            );
            this.tweens.add({
                targets: star,
                alpha: { from: 0.2, to: 0.9 },
                duration: Phaser.Math.Between(1500, 3000),
                yoyo: true, repeat: -1
            });
        }

        // 主标题
        let title = this.add.text(W / 2, H * 0.30, 'ABYSS MINER', {
            fontSize: '88px',
            color: '#ffffff',
            fontFamily: '"VT323", monospace',
            stroke: '#3344aa',
            strokeThickness: 6
        }).setOrigin(0.5);
        // 标题缓慢呼吸
        this.tweens.add({
            targets: title, alpha: { from: 0.85, to: 1 },
            duration: 2200, yoyo: true, repeat: -1
        });

        // 副标题
        this.add.text(W / 2, H * 0.40, 'A Grappling Adventure', {
            fontSize: '28px',
            color: '#aaaaaa',
            fontFamily: '"VT323", monospace',
            fontStyle: 'italic'
        }).setOrigin(0.5);

        // === 菜单按钮 ===
        const menuItems = [
            { label: 'START',       action: () => this._openSlotSelect() },
            { label: 'SAFEZONE1',   action: () => this._devJump('SafeZone1Scene') },
            { label: 'SAFEZONE2',   action: () => this._devJump('SafeZone2Scene') },
            { label: 'SAFEZONE2.5', action: () => this._devJump('SafeZone25Scene') },
            { label: 'SAFEZONE3',   action: () => this._devJump('SafeZone3Scene') },
            { label: 'SAFEZONE4',   action: () => this._devJump('SafeZone4Scene') },
            { label: 'SAFEZONE5',   action: () => this._devJump('SafeZone5Scene') },
            { label: 'OPTIONS',     action: () => this._openOptions() },
            { label: 'CREDITS',     action: () => this._openCredits() },
            { label: 'QUIT',        action: () => { alert('Thanks for playing!'); } }
        ];
        const baseY = H * 0.44;
        const itemSpacing = 42;

        menuItems.forEach((mi, idx) => {
            let y = baseY + idx * itemSpacing;
            let txt = this.add.text(W / 2, y, mi.label, {
                fontSize: '26px',
                color: '#aaaaaa',
                fontFamily: '"VT323", monospace'
            }).setOrigin(0.5);
            // hitArea 用宽松一点的范围，origin 0.5 时局部范围(-w/2, -h/2, w, h)
            // 但 Phaser hitTest 用 (pointerX - obj.x + displayOriginX) 计算，所以 hitArea 起点应该是 (0, 0)
            let w = txt.width, h = txt.height;
            txt.setInteractive(new Phaser.Geom.Rectangle(0, 0, w, h), Phaser.Geom.Rectangle.Contains);
            txt.on('pointerover', () => txt.setColor('#ffff00'));
            txt.on('pointerout',  () => txt.setColor('#aaaaaa'));
            txt.on('pointerdown', () => { if (typeof AudioSystem !== 'undefined') AudioSystem.sfx(this, 'Select'); mi.action(); });
        });

        // 底部版本号
        this.add.text(W - 20, H - 20, 'v0.1', {
            fontSize: '18px', color: '#555555',
            fontFamily: '"VT323", monospace'
        }).setOrigin(1, 1);

        // 显示鼠标
        this.game.canvas.style.cursor = 'url(assets/images/Mouse_cursor.png) 32 32, default';
    }

    _fadeAndStart(sceneKey, data, resetGuides = true) {
        if (this._fading) return;
        this._fading = true;
        // 重置 guide 已读状态（新游戏 = 从头开始；resume 时保留）
        if (resetGuides) {
            try { localStorage.removeItem('abyssMinerGuidesRead'); } catch {}
        }
        this.cameras.main.fadeOut(1000, 0, 0, 0);
        this.cameras.main.once('camerafadeoutcomplete', () => {
            // (用户) 大场景 create 同步重建几千墙体+皮肤, 主线程冻结几秒 — 黑屏像卡死.
            //   垫一个 DOM "Loading..." 层 (不依赖被冻结的 canvas), 等浏览器画出来再切场景;
            //   setInterval 冻结期不跑, 解冻后探测到新场景 RUNNING 自动摘掉.
            let div = document.getElementById('azm-scene-loading');
            if (!div) {
                div = document.createElement('div');
                div.id = 'azm-scene-loading';
                div.style.cssText = 'position:fixed;inset:0;background:#000;color:#cfcfcf;display:flex;align-items:center;justify-content:center;font:20px monospace;z-index:9999;letter-spacing:2px;';
                div.textContent = 'Loading...';
                document.body.appendChild(div);
            }
            const removeDiv = () => { const d = document.getElementById('azm-scene-loading'); if (d) d.remove(); };
            const iv = setInterval(() => {
                const scs = this.game.scene.getScenes(true);
                const sc = scs && scs[0];
                if (sc && sc.scene.key !== 'TitleScene' && sc.sys.settings.status === Phaser.Scenes.RUNNING) {
                    removeDiv(); clearInterval(iv);
                }
            }, 100);
            setTimeout(() => { removeDiv(); clearInterval(iv); }, 15000);   // 兜底
            setTimeout(() => { this.scene.start(sceneKey, data); }, 60);    // 给浏览器 ~2 帧画出 Loading 层
        });
    }

    // ═══ 存档位选择 (Hollow Knight 风格: 3 位, 读/新建/删) ═══
    _openSlotSelect() {
        if (this._modalOpen) return;
        this._modalOpen = true;
        const W = this.cameras.main.width;
        const H = this.cameras.main.height;

        const dim = this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.78).setDepth(900);
        const panel = this.add.container(W / 2, H / 2).setDepth(901);
        const PW = 660, PH = 470;
        const bg = this.add.rectangle(0, 0, PW, PH, 0x0a0a18, 0.97).setStrokeStyle(3, 0x6688aa);
        const title = this.add.text(0, -PH / 2 + 30, 'SELECT SAVE', {
            fontSize: '34px', color: '#ffcc55', fontFamily: '"VT323", monospace',
            stroke: '#000', strokeThickness: 4
        }).setOrigin(0.5);
        panel.add([bg, title]);

        const N = SaveSystem.NUM_SLOTS || 3;
        let rowItems = [];

        const buildSlots = () => {
            rowItems.forEach(o => { try { o.destroy(); } catch (e) {} });
            rowItems = [];
            for (let i = 1; i <= N; i++) {
                const y = -120 + (i - 1) * 92;
                const data = SaveSystem.getSlot(i);

                const rowBg = this.add.rectangle(0, y, PW - 80, 78, 0x14142a, 1)
                    .setStrokeStyle(2, 0x445577).setInteractive();
                rowBg.on('pointerover', () => rowBg.setFillStyle(0x1e1e3a, 1));
                rowBg.on('pointerout',  () => rowBg.setFillStyle(0x14142a, 1));

                const slotLbl = this.add.text(-PW / 2 + 60, y - 16, 'SLOT ' + i, {
                    fontSize: '24px', color: '#88ccff', fontFamily: '"VT323", monospace',
                    stroke: '#000', strokeThickness: 3
                }).setOrigin(0, 0.5);

                rowItems.push(rowBg, slotLbl);

                if (data) {
                    const zone = SaveSystem.zoneName(data.scene);
                    const info = this.add.text(-PW / 2 + 60, y + 14,
                        zone + '    \u25C6 ' + (data.crystalCount || 0) + '    \u2665 ' + (data.hearts || 0), {
                        fontSize: '18px', color: '#dddddd', fontFamily: '"VT323", monospace'
                    }).setOrigin(0, 0.5);
                    const tstamp = this.add.text(PW / 2 - 90, y - 16, SaveSystem.savedAgo(data.savedAt), {
                        fontSize: '13px', color: '#777788', fontFamily: '"VT323", monospace'
                    }).setOrigin(1, 0.5);

                    // 删除按钮 (2 次点击确认)
                    const del = this.add.text(PW / 2 - 56, y + 12, '\u2715', {
                        fontSize: '24px', color: '#ff5555', fontFamily: '"VT323", monospace',
                        stroke: '#000', strokeThickness: 3
                    }).setOrigin(0.5).setInteractive();
                    let confirm = false;
                    del.on('pointerover', () => del.setAlpha(0.7));
                    del.on('pointerout',  () => del.setAlpha(1));
                    del.on('pointerdown', () => {
                        if (!confirm) {
                            confirm = true;
                            del.setText('SURE?').setFontSize(16);
                            this.time.delayedCall(1800, () => {
                                if (del.active) { confirm = false; del.setText('\u2715').setFontSize(24); }
                            });
                            return;
                        }
                        SaveSystem.deleteSlot(i);
                        if (typeof AudioSystem !== 'undefined') AudioSystem.sfx(this, 'Select');
                        buildSlots();
                    });

                    rowBg.on('pointerdown', () => {
                        if (typeof AudioSystem !== 'undefined') AudioSystem.sfx(this, 'Select');
                        this._resumeSlot(i, data);
                    });
                    rowItems.push(info, tstamp, del);
                } else {
                    const info = this.add.text(-PW / 2 + 60, y + 14, '- Empty -  (click to start new)', {
                        fontSize: '18px', color: '#777777', fontFamily: '"VT323", monospace'
                    }).setOrigin(0, 0.5);
                    rowBg.on('pointerdown', () => {
                        if (typeof AudioSystem !== 'undefined') AudioSystem.sfx(this, 'Select');
                        this._newGameSlot(i);
                    });
                    rowItems.push(info);
                }
            }
            panel.add(rowItems);
        };
        buildSlots();

        const backBtn = this.add.text(0, PH / 2 - 38, '[ BACK ]', {
            fontSize: '26px', color: '#ff8888', fontFamily: '"VT323", monospace',
            stroke: '#000', strokeThickness: 4
        }).setOrigin(0.5).setInteractive();
        backBtn.on('pointerover', () => backBtn.setColor('#ffffff'));
        backBtn.on('pointerout',  () => backBtn.setColor('#ff8888'));
        backBtn.on('pointerdown', () => { dim.destroy(); panel.destroy(); this._modalOpen = false; });
        panel.add(backBtn);
    }

    // dev 菜单直接跳场景 (不绑存档位, 清空 current 避免污染真存档)
    _devJump(sceneKey) {
        if (typeof SaveSystem !== 'undefined') SaveSystem.setCurrentSlot(null);
        this._fadeAndStart(sceneKey, null, true);
    }

    _newGameSlot(n) {
        SaveSystem.deleteSlot(n);          // 清空旧数据 (新游戏)
        SaveSystem.setCurrentSlot(n);      // deleteSlot 可能清 current, 重设
        this._fadeAndStart('StartIntroScene', null, true);   // 新游戏 → 重置 guide 已读
    }

    _resumeSlot(n, data) {
        SaveSystem.setCurrentSlot(n);
        // 恢复需要在 registry 里的标志 (跨场景持久)
        try { this.registry.set('pickaxeUpgraded', !!data.pickaxeUpgraded); } catch (e) {}
        this._fadeAndStart(data.scene || 'SafeZone1Scene', data, false);   // resume → 保留 guide
    }

    _openOptions() {
        if (this._modalOpen) return;
        // (用户) 标题设置 = 游戏内 Settings 同款面板 (视频/音频/按键/游戏页签), 仅去掉 "保存并退出"
        if (typeof SettingsSystem === 'undefined') return;
        if (!this.settingsSystem) {
            this.settingsSystem = new SettingsSystem(this, { titleMode: true });
            this.settingsSystem.init();
            const origClose = this.settingsSystem.close.bind(this.settingsSystem);
            this.settingsSystem.close = () => { origClose(); this._modalOpen = false; };
        }
        this._modalOpen = true;
        this.settingsSystem.open();
    }

    _openCredits() {
        if (this._modalOpen) return;
        this._modalOpen = true;
        const W = this.cameras.main.width;
        const H = this.cameras.main.height;

        const dim = this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.7).setDepth(900);
        const panel = this.add.container(W / 2, H / 2).setDepth(901);
        const PW = 600, PH = 480;
        const bg = this.add.rectangle(0, 0, PW, PH, 0x0a0a18, 0.97).setStrokeStyle(3, 0x6688aa);
        const title = this.add.text(0, -PH / 2 + 30, 'CREDITS', {
            fontSize: '36px', color: '#ffcc55', fontFamily: '"VT323", monospace',
            stroke: '#000', strokeThickness: 4
        }).setOrigin(0.5);

        const lines = [
            { y: -PH / 2 + 90,  text: 'ABYSS MINER',          size: '32px', color: '#88ccff' },
            { y: -PH / 2 + 130, text: 'A Roguelike Mining Adventure', size: '20px', color: '#aaaaaa' },
            { y: -50,           text: 'Programming',          size: '22px', color: '#ffcc55' },
            { y: -20,           text: 'Ang Yen Peng',         size: '20px', color: '#ffffff' },
            { y: 10,            text: 'Backend & Database',   size: '22px', color: '#ffcc55' },
            { y: 40,            text: 'Low Yong Yi',          size: '20px', color: '#ffffff' },
            { y: 70,            text: 'Art & Level Design',   size: '22px', color: '#ffcc55' },
            { y: 100,           text: 'Dylan',                size: '20px', color: '#ffffff' },
            { y: 150,           text: 'Built with Phaser 3',  size: '18px', color: '#888888' }
        ];
        const texts = lines.map(l => this.add.text(0, l.y, l.text, {
            fontSize: l.size, color: l.color, fontFamily: '"VT323", monospace',
            stroke: '#000', strokeThickness: 3
        }).setOrigin(0.5));

        const closeBtn = this.add.text(0, PH / 2 - 50, 'CLOSE', {
            fontSize: '28px', color: '#ff8888', fontFamily: '"VT323", monospace',
            stroke: '#000', strokeThickness: 4
        }).setOrigin(0.5).setInteractive();
        closeBtn.on('pointerover', () => closeBtn.setColor('#ffffff'));
        closeBtn.on('pointerout',  () => closeBtn.setColor('#ff8888'));
        closeBtn.on('pointerdown', () => {
            dim.destroy();
            panel.destroy();
            this._modalOpen = false;
        });

        panel.add([bg, title, ...texts, closeBtn]);
    }
}